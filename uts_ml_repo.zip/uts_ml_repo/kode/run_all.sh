#!/usr/bin/env bash
# Satu perintah untuk mereproduksi semua angka, gambar, dan file prediksi.
# Taruh data mentah (*.csv.gz dari data_uts_ml.zip) di folder data/ lebih dulu.
set -euo pipefail
cd "$(dirname "$0")"
python 01_regresi.py       # -> ../prediksi_regresi.csv, ../hasil/regresi.json
python 02_klasifikasi.py   # -> ../prediksi_klasifikasi.csv, ../hasil/klasifikasi.json
python 03_clustering.py    # -> ../cluster.csv, ../hasil/clustering.json
python 04_laporan.py       # -> ../laporan.pdf
